import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:quiz_app/components/answer_button.dart'; // Fixed the import path
import 'package:quiz_app/data/question.dart';

import '../components/answer_button .dart';

class QuestionsScreen extends StatefulWidget {
  const QuestionsScreen({super.key});

  @override
  State<QuestionsScreen> createState() => _QuestionsScreenState();
}
class _QuestionsScreenState extends State<QuestionsScreen> {
  var currentQuestionIndex = 0;
  void answerQuestion(){
    setState(() {
      currentQuestionIndex++;
    });
  }
  @override
  Widget build(BuildContext context) {
    final currentQuestion = questions[currentQuestionIndex];

    return Center(

      child: Container(
        margin: const EdgeInsets.all(40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              textAlign: TextAlign.center,
              currentQuestion.text,
              style: const TextStyle(
                fontSize: 24,
                color: Colors.white,

              ),
            ),
            const SizedBox(height:5),
            ...currentQuestion.getShuffledAnswer().map(
                  (answer) => AnswerButton(
                text: answer,
                onTap: answerQuestion, // Fixed function declaration
              ),
            ).toList(), // Ensure `.map()` result is converted to a list
          ],
        ),
      ),
    );
  }
}