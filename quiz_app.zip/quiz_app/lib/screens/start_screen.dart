//import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class StartScreen extends StatelessWidget {
  const StartScreen(this.startQuize,{super.key});

  final void Function() startQuize;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset('qlo.png', width: 300,),
          const SizedBox(height: 80,),  // ✅ Added missing comma here
          const Text(
            'Learn Flutter the fun Way!', // ✅ Fixed typo in "Learn"
            style: TextStyle(
              fontSize: 24,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 30,),
          OutlinedButton.icon(
            icon: const Icon(Icons.arrow_right_alt),
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.white,
            ),
            onPressed: startQuize,
            label: const Text('Start Quiz'), // ✅ Fixed typo in "Quiz"
          ),
        ],
      ),
    );
  }
}
