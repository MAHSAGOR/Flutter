import '../models/quiz_question.dart';

const questions = [
  QuizQuestion('1. What are the main building blocks of Flutter UIs ?',
    [
      'Widgets',
      'Components',
      'Blocks',
      'Functions',
    ],
  ),
  QuizQuestion(
    'Which widget is used to create a button in Flutter?',
    [
      'ElevatedButton',
      'ButtonWidget',
      'ClickableView',
      'ActionButton',
    ],
  ),
  QuizQuestion(
    'Which language is primarily used to build Flutter apps?',
    [
      'Dart',
      'Java',
      'Swift',
      'Kotlin',
    ],
  ),
  QuizQuestion(
    'What is the purpose of the "pubspec.yaml" file in a Flutter project?',
    [
      'To manage dependencies',
      'To define app routes',
      'To store user data',
      'To handle navigation',
    ],
  ),
  QuizQuestion(
    'Which widget is used to display a list of items in Flutter?',
    [
      'ListView',
      'Column',
      'Row',
      'Container',
    ],
  ),
  QuizQuestion(
    'How do you define a Stateful widget in Flutter?',
    [
      'By extending StatefulWidget',
      'By using StatelessWidget',
      'By creating a new Dart class',
      'By defining a new function',
    ],
  ),
  QuizQuestion(
    'What is the default programming paradigm of Flutter?',
    [
      'Declarative UI',
      'Imperative UI',
      'Object-Oriented UI',
      'Functional UI',
    ],
  ),
  QuizQuestion(
    'Which widget is used to create a flexible UI layout in Flutter?',
    [
      'Flexible',
      'Expanded',
      'Stack',
      'Scaffold',
    ],
  ),
  QuizQuestion(
    'What does the "setState()" method do in Flutter?',
    [
      'Updates the UI by rebuilding the widget',
      'Deletes the widget',
      'Creates a new widget',
      'Runs the app',
    ],
  ),
  QuizQuestion(
    'Which widget is commonly used as a root widget for Flutter apps?',
    [
      'MaterialApp',
      'Container',
      'Scaffold',
      'Column',
    ],
  ),
];